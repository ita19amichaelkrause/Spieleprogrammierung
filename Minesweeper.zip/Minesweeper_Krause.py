###Leider Unvollständig, da ich Schwierigkeiten hatte

import pygame
import sys
from random import randrange
from pygame.constants import (QUIT, KEYDOWN, K_LEFT, K_RIGHT, K_Q

#FARBEN

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
GRAY = (127, 127, 127)
BLUE = (0, 0, 255)


#Breite und Höhe der einzelnen Kästchen erstellen
WIDTH = 50
HEIGHT = 50

#Anzahl der Quadrate
NUMSQUARES = 10

#Abstand zwischen jeder Zelle bestimmen
DISTANCE = 5
LEFTCLICK = 1
                              

class Spiel:
    def __init__(self):
        #Gitter für die Quadrate erstellen
        self.grid = [[self.Cell(x, y) for x in range(NUMSQUARES)] for y in range(NUMSQUARES)]
        self.init = False
        self.game_lost = False
        self.game_won = False
        self.num_bombs = 10
        self.squares_x = NUMSQUARES
        self.squares_y = NUMSQUARES




    def draw(self):
        screen.fill(BLACK)
        #Gitter zeichnen
        for row in range(self.squares_y):
            for column in range(self.squares_x):
                color = WHITE
                if self.grid[row][column].is_visible:
                     color = RED if self.grid[row][column].has_bomb else GRAY  
                elif self.grid[row][column].has_flag:
                    color = BLUE

    def gameover(self):



    def Bomben_platzieren(self):


    def Bomben_zaehlen(self):
        

    def Bombenanzahl(self):


    def Reset(self):


    def Sieg_checken(self):



class Settings:
    def __init__(self):
                
        

#Initialsieren der Screen Settings 


pygame.init()
clock = pygame.time.Clock()





if __name__ == '__main__':
    pygame.init()

    running = True
    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == K_Q:
                running = False


    game.draw()
    pygame.display.flip()
    pygame.quit()


    
