#Imports

import pygame
import random
import math
import time
pygame.font.init()
pygame.init()

#Farben 

WEISS = ( 255, 255, 255)
BLAU = (0,0,255)
CYAN = (0,255,255)
ORANGE=(255,102,0)
GELB = (255,255,0)
GRÜN = ( 0, 255, 0)
SILBER = (211,211,211)
SCHWARZ = ( 0, 0, 0)
ROT = ( 255, 0, 0) 
KOLLISION = ROT
FARBE1 = GELB
FARBE2 = CYAN
FARBE3 = SCHWARZ

#Settings

screenx = 700
screeny = 400
screencolor = WEISS 
minr = 4
maxr = 12                    
bubblelinewidth = 3
kanten = 120           
bubblecolor = BLAU 
maxbubble = 4 
clocktick = 60
run = True    
cursor_png = pygame.image.load("cursor.png")
cursor_png = pygame.transform.scale(cursor_png, (40, 40))

#Klasse Bubbles

class Bubbles:
	def __init__(self,x,y,r,groesse):
		self.x = x
		self.y = y
		self.r = r
		self.groesse = groesse

	def options(self,bubblelinewidth,bubblecolor):
		self.width = bubblelinewidth
		self.color = bubblecolor

	def value(self):
		return self.value

	def kollision(self):
		print("Kollision!")

	def kollisionrand(self):
		print("Bubble am Rand!")

	def schaden(self):
		self.width = 0
		self.color = ROT


def pruefxyr(x,y,r,screenx,screeny ,kanten,anzahlbubbles):
    if kollisionrand(x, y,r,screenx,screeny ,kanten) == False:
        return False
    for bubble in anzahlbubbles:
        w = math.pow((math.pow((x-bubble.x), 2)+math.pow((y-bubble.y), 2)), 1)
        if w -r-bubble.r <= 15:
            return False
    return True

def abstand (x1, y1, x2, y2):
    w = math.pow((math.pow((x1 - x2), 4) +math.pow((y1 - y2), 4)), 2)
    return w

def xyr(minr, maxr, screenx, screeny, kanten, anzahlbubbles):
    x = 0 
    y = 0 
    r = 5 
    groesse = 0
    c = Bubbles(x, y, r, groesse)
    while pruefxyr(x, y, r, screenx, screeny, kanten, anzahlbubbles) != True:
        x = random.randint(0, screenx)
        y = random.randint(0, screeny)
        r = random.randint(minr, maxr)
        groesse = random.randint(1, 10)
        c = Bubbles(x, y, r, groesse)
    return c


def kollisionrand(x, y, r, screenx, screeny, kanten):
    if x+r >= screenx-kanten:
        return False
    if x-r <= kanten:
        return False
    if y+r >= screeny - kanten:
        return False
    if y-r <= kanten:
        return False
    
    return True


def mouseoption(bubble, mousex, mousey):
    w = math.pow((math.pow((bubble.x-mousex), 2)+math.pow((bubble.y-mousey), 2)), 0.5)
    if w == bubble.r:
        pass
    if w < bubble.r:
        return("Getroffen")
    if w> bubble.r:
        pass

def pauseoptions(anzahlbubbles, screenx, screeny, *args):
    for c in anzahlbubbles:
        c.options(0,(169,169,169))
    optionbubble = Bubbles(screenx*3/4, screeny *2/3, 50, 0)
    optionbubble.options(0, FARBE2)
    anzahlbubbles.append(optionbubble)
    if args[0] == "pause":
        optionbubble = Bubbles(screenx/4, screeny *2/3, 50, 0)
        optionbubble.options(0, FARBE1)
        anzahlbubbles.append(optionbubble)
    if args[0] == "verloren": 
        optionbubble = Bubbles(screenx/2,screeny *2/3, 50, 0)
        optionbubble.options(0, ORANGE)
        anzahlbubbles.append(optionbubble)
        optionbubble = Bubbles(screenx/4, screeny *2/3, 50, 0)
        optionbubble.options(0, FARBE3)
        anzahlbubbles.append(optionbubble)

def kollision_pruefen(bubble1, bubble2):
    w = math.pow((math.pow((bubble1.x-bubble2.x),2)+math.pow((bubble1.y-bubble2.y),2)),0.5)
    if bubble1.color != BLAU or bubble2.color != BLAU:
        return 
    if w == 0:
        pass
    if w == bubble1.r + bubble2.r:
        pass
    if w < bubble1.r + bubble2.r and w>0:
        return("Kollidiert")
    if w> bubble1.r + bubble2.r:
        pass


def dateien():
    f = open("highscores.txt", "r")
    punkte = []
    for x in f:
        if x != "":
            punkte.append(x.split(":"))
    f.close()
    punkte.sort(key = lambda x:int(x[1]), reverse = True)
    return punkte

def dateilesen(scores):
    f = open("highscores.txt", "w")
    for x in scores:
        f.write(x[0]+":"+x[1])
    f.close()


#Screen
clock = pygame.time.Clock()
screen = pygame.display.set_mode((screenx, screeny))
pygame.display.set_caption("Bubbles ITA19a")
anzahlbubbles = []
punkte = 0
endtick = 0
nameeingabe = False
spielername = "Name"
written = True
pause = False


#Hauptschleife
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: 
              run = False 
        if event.type == pygame.KEYDOWN:
            if event.key == 10:
                nameeingabe = False
                scores = dateien()
                scores.sort(key = lambda x:int(x[1]),reverse = True)
                scores.append((spielername, f'{punkte:.2f}\n'))
                scores.remove(scores[len(scores)-1])
                dateilesen(scores)
            if event.key == 8:
                if nameeingabe == True:
                    spielername = spielername[:-2]
            if nameeingabe == True:
                spielername += chr(event.key)
            if event.key == pygame.K_p and nameeingabe == False: 
                pause = True
                pauseoptions(anzahlbubbles, screenx, screeny, "pause")
                screencolor = WEISS
        if event.type == pygame.MOUSEBUTTONUP:
           if event.button == 3:
               pause = True
               pauseoptions(anzahlbubbles,screenx,screeny ,"pause")
               screencolor= WEISS
           if event.button == 1:
                mousex = pygame.mouse.get_pos()[0]
                mousey = pygame.mouse.get_pos()[1]
                for bubble in anzahlbubbles:
                    if mouseoption(bubble,mousex,mousey) == "Getroffen":
                        if bubble.color == BLAU:
                            endtick = pygame.time.get_ticks() + 150
                            myfont = pygame.font.SysFont('Goudy Stout', 16)
                            einzel = myfont.render(f'+{bubble.r:.2f}', False, (0, 0, 0))
                            einzel_rect = einzel.get_rect(center = (bubble.x, bubble.y))          
                            bubble.schaden()
                            pygame.mixer.Sound.play(pygame.mixer.Sound("click.wav"))
                            punkte += bubble.r
                        if bubble.color == FARBE1:
                            pause = False
                            l = len(anzahlbubbles)
                            anzahlbubbles.remove(anzahlbubbles[l-1])
                            l = len(anzahlbubbles)
                            anzahlbubbles.remove(anzahlbubbles[l-1])
                            screencolor = WEISS
                        if bubble.color == FARBE2:
                            run = False
                        if bubble.color == FARBE3:
                            anzahlbubbles.clear()
                            screencolor = WEISS
                            punkte = 0
                            written=False
                            pause = False 
                        if bubble.color == CYAN:
                            nameeingabe = True
#Kollision mit dem Rand
    for bubble in anzahlbubbles:
        if kollisionrand(bubble.x,bubble.y,bubble.r,screenx,screeny ,0) != True  and pause == False:
            pauseoptions(anzahlbubbles,screenx,screeny ,"verloren")
            pygame.mixer.Sound.play(pygame.mixer.Sound("gameover.wav"))
            pause=True
#Kollision mit Bubbles                            
    for bubble1 in anzahlbubbles:
        for bubble2 in anzahlbubbles:
            if kollision_pruefen(bubble1,bubble2) == "Kollision" and pause == False:
                pauseoptions(anzahlbubbles,screenx,screeny ,"verloren")
                screencolor = ROT
                pause = True               
    if len(anzahlbubbles)  < maxbubble and pause == False:
        c = xyr(minr,maxr,screenx, screeny ,kanten,anzahlbubbles)
        c.options(bubblelinewidth,bubblecolor)
        anzahlbubbles.append(c)
    if pause == False:
        for bubble in anzahlbubbles:
            bubble.r += bubble.groesse/15
            bubble.groesse += bubble.groesse/30
    screen.fill(screencolor)
    myfont = pygame.font.SysFont("Goudy Stout", 16)
    art = myfont.render(f'Punkte :  + {punkte:.2f}', False, (0, 0, 0))
    screen.blit(art,(0,0))     
 #Highscores
    c = anzahlbubbles[len(anzahlbubbles)-1]
    if pause == True and c.color == SCHWARZ and nameeingabe == False:
        spacebetweenlines = 20   
        for i in range(0,5):
            scores = dateien()
            x = ''.join(e for e in scores[i][0] if e.isalnum()) +" = " + ''.join(e for e in scores[i][1] if e.isalnum())
            text = myfont.render(x, False, SCHWARZ)
            text_rect = text.get_rect(center = (screenx/2,screeny /5+spacebetweenlines*i))          
            screen.blit(text,text_rect)
    
    def zeigetext(text,color):
        text = myfont.render(text, False, color)
        text_rect = text.get_rect(center = (c.x, c.y))          
        screen.blit(text,text_rect) 
    for c in anzahlbubbles:
        if c.color == GELB: 
            zeigetext("Fortsetzen?",SCHWARZ)
        if c.color == SCHWARZ: 
            zeigetext("Neustart", SCHWARZ)
        if c.color == CYAN: 
            zeigetext("Verlassen",SCHWARZ)
        if c.color == ORANGE: 
            if spielername == "Spieler":
                zeigetext("Name eingeben",SCHWARZ)
            if spielername != "" and spielername != "Spieler":
                zeigetext(spielername,SCHWARZ)
    
    mousex = pygame.mouse.get_pos()[0]
    mousey = pygame.mouse.get_pos()[1]
    cursor_png_rect = cursor_png.get_rect()
    cursor_png_rect.center = pygame.mouse.get_pos() 
    for bubble in anzahlbubbles:
        if mouseoption(bubble,mousex,mousey) == "Getroffen":
            if bubble.color == BLAU: 
                pygame.mouse.set_visible(False)
                screen.blit(cursor_png, cursor_png_rect) 
                break
        elif mouseoption(bubble,mousex,mousey) != "Getroffen":
            pygame.mouse.set_visible(True)

    if(endtick > pygame.time.get_ticks()):
        screen.blit(einzel,einzel_rect)
    else:
        einzel = None
        einzel_rect = None
    pygame.display.flip()
    clocktick = clocktick +0.1
    if clocktick >= 30:
        clocktick =30
    clock.tick(clocktick)

    for bubble in anzahlbubbles:
        if bubble.width == 0 and bubble.color == KOLLISION:
            anzahlbubbles.remove(bubble)
            
pygame.quit()



