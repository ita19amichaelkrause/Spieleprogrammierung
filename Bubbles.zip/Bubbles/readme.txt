Leider habe ich es nicht geschafft, die Bubbles auf der Oberfläche erscheinen zu lassen.
Das liegt daran, dass ich die Draw funktion benutzen wollte aber Fehlermeldungen bekam die ich nicht kannte.
Bildlich sind sie zwar nicht da aber wenn man hin- und herklickt kann man erkennen das sie sogesehen da sind.